
import streamlit as st
import cv2
import numpy as np
from PIL import Image
import tempfile
import os

st.set_page_config(page_title="Pencil Sketch Converter", layout="wide")

def pencil_sketch(image, brightness=0, contrast=1.0, color=False):
    image = np.array(image)
    gray_image = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    inverted = 255 - gray_image
    blurred = cv2.GaussianBlur(inverted, (21, 21), 0)
    sketch = cv2.divide(gray_image, 255 - blurred, scale=256)
    
    if brightness != 0 or contrast != 1.0:
        sketch = cv2.convertScaleAbs(sketch, alpha=contrast, beta=brightness)

    if color:
        color_sketch = cv2.cvtColor(sketch, cv2.COLOR_GRAY2RGB)
        color_sketch = cv2.applyColorMap(color_sketch, cv2.COLORMAP_PINK)
        return color_sketch

    return sketch

st.title("🖼️ Pencil Sketch Web App")
st.markdown("Upload an image or use webcam to convert to pencil sketch.")

mode = st.sidebar.radio("Choose Mode", ["Upload Image", "Webcam Snapshot", "Batch Upload"])
brightness = st.sidebar.slider("Brightness", -100, 100, 0)
contrast = st.sidebar.slider("Contrast", 0.5, 3.0, 1.0)
colorize = st.sidebar.checkbox("🎨 Stylized Color Sketch")

if mode == "Upload Image":
    file = st.file_uploader("Upload an image", type=["jpg", "jpeg", "png"])
    if file:
        image = Image.open(file).convert("RGB")
        st.image(image, caption="Original", use_column_width=True)
        sketch = pencil_sketch(image, brightness, contrast, color=colorize)
        st.image(sketch, caption="Pencil Sketch", use_column_width=True)
elif mode == "Webcam Snapshot":
    picture = st.camera_input("Take a picture")
    if picture:
        image = Image.open(picture).convert("RGB")
        st.image(image, caption="Original", use_column_width=True)
        sketch = pencil_sketch(image, brightness, contrast, color=colorize)
        st.image(sketch, caption="Pencil Sketch", use_column_width=True)
elif mode == "Batch Upload":
    files = st.file_uploader("Upload multiple images", type=["jpg", "jpeg", "png"], accept_multiple_files=True)
    if files:
        for file in files:
            image = Image.open(file).convert("RGB")
            sketch = pencil_sketch(image, brightness, contrast, color=colorize)
            st.image(sketch, caption=f"Sketch of {file.name}", use_column_width=True)
