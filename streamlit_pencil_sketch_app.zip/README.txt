🖼️ Pencil Sketch Streamlit App - Instructions

1. Make sure Python is installed (3.8+ recommended)
2. Open terminal or command prompt
3. Navigate to the project folder
4. Run: pip install -r requirements.txt
5. Then run: streamlit run app.py
6. Upload image / take webcam pic / batch upload and enjoy!

Optional Enhancements Coming:
- Firebase Login
- Upload History

- Created with ❤️ by ChatGPT